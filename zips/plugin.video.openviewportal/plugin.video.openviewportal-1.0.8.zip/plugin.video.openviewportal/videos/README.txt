This is an empty directory that serves to remind you that all local videos
are stored at /home/pi/videos.  They are not stored on Github.

These videos are based around getting the user started when they get their 
product and have not yet connected to the internet.  There is also a test video 
that is used in half split fault finding, i.e. is the problem local environment 
or internet related.
