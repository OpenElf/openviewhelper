#!/usr/bin/python

############### Imports ################################################

import os,xbmc

########################################################################


xbmc.executescript('/home/pi/.xbmc/addons/plugin.video.openviewportal/scripts/ov_script.py')
