Copy the autoexec.py file to /home/pi/.xbmc/userdata
