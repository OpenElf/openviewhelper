This is an empty directory within the repo on github.  The directory is
only populated during a product build cycle with videos that are housed
on the SD card user.  These videos are based around getting the user
started when they get their product and have not yet connected to the
internet.  There is also a test video that is used in half split fault
finding, i.e. is the problem local environment or internet related.
